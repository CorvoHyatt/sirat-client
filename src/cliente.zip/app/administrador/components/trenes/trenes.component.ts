import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trenes',
  templateUrl: './trenes.component.html',
  styleUrls: ['./trenes.component.css']
})
export class TrenesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
