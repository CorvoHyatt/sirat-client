import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-cotizacion-destinos',
  templateUrl: './cotizacion-destinos.component.html',
  styleUrls: ['./cotizacion-destinos.component.css']
})
export class CotizacionDestinosComponent implements OnInit {

  constructor() { }
  
  ngOnInit(): void {

  }
}
