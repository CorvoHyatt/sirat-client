import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rechazar-orden',
  templateUrl: './rechazar-orden.component.html',
  styleUrls: ['./rechazar-orden.component.css']
})
export class RechazarOrdenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
