export class Agencia{
    idAgencia: number;
    nombre: string;
    constructor() {
        this.idAgencia = 0;
        this.nombre = ``;
    }
}