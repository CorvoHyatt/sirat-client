export class Agente {
  idAgente: number;
  idAgencia: number;
  nombre: string;
  apellidos: string;
  correo: string;

  constructor() {
    this.idAgente = 0;
    this.idAgencia = 0;
    this.nombre = ``;
    this.apellidos = ``;
    this.correo = "";
  }
}
