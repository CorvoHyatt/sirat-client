export class Area{
    idArea: number;
    nombre: string;

    constructor() {
        this.idArea = 0;
        this.nombre = ``;
    }
}