export class Canasta{
    idCanasta: number;
    idCotizacion: number;
    idActividad: number;
    tipo: number;
    estatus: number;

    constructor() {
        this.idCanasta = 0;
        this.idCotizacion = 0;
        this.idActividad = 0;
        this.tipo = 0;
        this.estatus = 0;
    }
}