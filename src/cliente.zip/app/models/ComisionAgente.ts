export class ComisionAgente {
  idAgente: number;
  tipoActividad: number;
  comision: number;

  constructor() {
    this.idAgente = 0;
    this.tipoActividad = 0;
    this.comision = 0;
  }
}
