export class Continente{
    idContinente: number;
    nombre: string;

    constructor() {
        this.idContinente = 0;
        this.nombre = ``;    
    }
}