export class Destino {
  idDestino: number;
  idCotizacion: number;
  idCiudad: number;
  versionCotizacion: number;

  constructor() {
    this.idDestino = 0;
    this.idCotizacion = 0;
    this.idCiudad = 0;
    this.versionCotizacion = 0;
  }
}
