export class Divisa {
    idDivisa: number;
    divisa: string;
    valor: number;
    descripcion: string;

    constructor() {
        this.idDivisa = 0;
        this.divisa = '';
        this.valor = 0.0;
        this.descripcion='';
    }
}
