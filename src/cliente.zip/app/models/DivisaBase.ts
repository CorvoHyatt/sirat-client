export class DivisaBase {
  idDivisaBase: number;
  divisa: string;
  valor: number;

  constructor() {
    this.idDivisaBase = 0;
    this.divisa = ``;
    this.valor = 0;
  }
}
