export class Imagen {
    nombre: string;
    src: string;

    constructor() {
        this.nombre = "";
        this.src = "";
    }
}