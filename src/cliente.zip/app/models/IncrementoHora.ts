export class incrementoHora {
  idIncremento: number;
  horaInicial: string;
  horaFinal: string;

  constructor() {
    this.idIncremento = 0;
    this.horaInicial = ``;
    this.horaFinal = ``;
  }
}
