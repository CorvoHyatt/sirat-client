export class Jerarquia{

    idAreaPrincipal: number;
    idAreaSubordinada: number;

    constructor() {
        this.idAreaPrincipal = 0;
        this.idAreaSubordinada = 0;
    }
}