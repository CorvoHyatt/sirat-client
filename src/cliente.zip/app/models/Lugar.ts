export class Lugar {
  idLugar: number;
  nombre: string;
  tipo: number;
  latitud: number;
  longitud: number;

  constructor() {
    this.idLugar = 0;
    this.nombre = ``;
    this.tipo = 0;
    this.latitud = 0;
    this.longitud = 0;
  }
}
