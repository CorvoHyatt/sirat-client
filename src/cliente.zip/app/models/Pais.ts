export class Pais{
    id: number;
    idContinente: number;
    nombre: string;
    bandera: string;
    diasAltos: string;
    constructor() {
        this.id = 0;
        this.idContinente = 0;
        this.nombre = ``;
        this.bandera = ``;
        this.diasAltos = ``;
    }
}