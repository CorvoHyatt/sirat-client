export class PorcentajeIncremento {
    porcentaje: number;
    constructor() {
        this.porcentaje = 0;
    }

}
