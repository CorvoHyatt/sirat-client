export class ProductoDiaCerrado{
    idProductoDiaCerrado: number;
    idProducto: number;
    fecha: string;
    

    constructor() {
        this.idProductoDiaCerrado-0;
        this.idProducto=0;
        this.fecha=``;
        
    }
}