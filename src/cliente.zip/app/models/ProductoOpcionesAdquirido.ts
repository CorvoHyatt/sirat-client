export class ProductoOpcionesAdquirido{

    idProductoAdquirido: number;
    idProductoOpcion: number;

    constructor(){
        this.idProductoAdquirido =0;
        this.idProductoOpcion =0;
    }
}