export class ProductoResumen {
  tipo: number;
  fecha: string;
  nombre: string;
  desde: string;
  hacia: string;
  hora : string;

 

  constructor() {
      this.tipo=0;
      this.fecha="";
      this.nombre="";
      this.desde="";
      this.hacia="";
      this.hora="";
  }

}