export class ProductoTarifa {
  idProductoTarifa: number;
  idProducto: number;
  numPersonas: number;
  tarifa: number;

  constructor() {
    this.idProductoTarifa = 0;
    this.idProducto = 0;
    this.numPersonas = 0;
    this.tarifa = 0;
  }
}
