export class Subcategoria{
    idSubcategoria: number;
    nombre: string;

    constructor() {
        this.idSubcategoria = 0;
        this.nombre = ``;
    }
}