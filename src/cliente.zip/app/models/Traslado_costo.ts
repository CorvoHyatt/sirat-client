export class Traslado_costo {
    idTrasladoCosto: number;
    idTraslado: number;
    idVehiculo: number;
    costo: number;
    idDivisa: number;
    notas: string;
    
   
    constructor() {
        this.idTrasladoCosto = 0;
        this.idTraslado = 0;
        this.idVehiculo = 0;
        this.costo = 0;
        this.idDivisa = 0;
        this.notas = "";

    }

}

