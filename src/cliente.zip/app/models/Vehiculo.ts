export class Vehiculo {

    idVehiculo: number;
    nombre: string;
    pasajerosMax: number;
    //equipajeDeMano: number;
    //equipajeEstandar: number;
    //img: string;
    maletasMax: number;
    lujo: number;
    img: string;
    maletasManoMax: number;

    constructor() {
        this.idVehiculo = 0;
        this.nombre = '';
        this.pasajerosMax = 0;
        //this.equipajeDeMano = 0; 
        //this.equipajeEstandar = 0;
        //this.img = '';
        this.maletasMax = 0;
        this.lujo =0;
        this.img = "";
        this.maletasManoMax = 0;
    }
}

