export class Cotiz_dest_version {
  idDestino: number;
  idCotizacion: number;
  versionCotizacion: number;

  constructor() {
    this.idDestino = 0;
    this.idCotizacion = 0;
    this.versionCotizacion = 0;
  }
}
