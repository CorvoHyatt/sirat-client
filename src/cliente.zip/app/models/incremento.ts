export class Incremento{
    idIncremento: number;
    idActividad: number;
    tipoActividad: number;
    tipo: number;
    nombre: string;
    porcentaje: number;
    constructor() {
        this.idIncremento = 0;
        this.idActividad = 0;
        this.tipoActividad = 0;
        this.tipo = 1;
        this.nombre = ``;
        this.porcentaje = 0;
    }
}