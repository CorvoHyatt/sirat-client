export class IncrementoFecha{
    idIncremento: number;
    fechaInicial: string;
    fechaFinal: string;

    constructor() {
        this.idIncremento=0;
        this.fechaInicial=``;
        this.fechaFinal=``;
    }
} 