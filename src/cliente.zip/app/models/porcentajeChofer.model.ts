export class PorcentajeChofer {
    porcentaje: number;
    constructor() {
        this.porcentaje = 0;
    }

}

