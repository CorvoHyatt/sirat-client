export class ProductoHorario {
  idProductoHorario: number;
  idProducto: number;
  hora: string;

  constructor() {
    this.idProductoHorario = 0;
    this.idProducto = 0;
    this.hora = ``;
  }
}
