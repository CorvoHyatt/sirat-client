export class ProductoTransporteAdquirido{

    idProductoAdquirido: number;
    idProductoTransporte: number;

    constructor(){
        this.idProductoAdquirido =0;
        this.idProductoTransporte=0;
    
    }
}