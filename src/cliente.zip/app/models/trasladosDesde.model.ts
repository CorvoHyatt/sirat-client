export class TrasladosDesde {
    idDesde: number;
    nombre: string;
    desdeOriginal: string;
    constructor() {
        this.idDesde = 0;
        this.nombre = "0";
        this.desdeOriginal = "";
    }

}