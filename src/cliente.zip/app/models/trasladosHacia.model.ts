export class TrasladosHacia {
    idHacia: number;
    nombre: string;
    haciaOriginal: string;
    constructor() {
        this.idHacia = 0;
        this.nombre = "0";
        this.haciaOriginal = "";
    }

}