export const environment = {
  production: true,
  API_URI: "https://5rives.com:49353",
  API_URI_IMAGES: "https://5rives.com:49354",
  API_URI_CORREOS: "https://5rives.com:49354"

};
