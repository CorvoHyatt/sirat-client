export class PaisesAction {
  static readonly type = '[Paises] Add item';
  constructor(public payload: string) { }
}
